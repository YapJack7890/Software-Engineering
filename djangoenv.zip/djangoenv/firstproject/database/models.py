from django.db import models

# Create your models here.
class Parent(models.Model):
    Parent_ID = models.CharField('Parent ID', max_length=5,)
    Parent_Phone_Num = models.IntegerField('Parent Phone Number')
    Parent_Username = models.CharField('Parent Username', max_length=50)
    Parent_Password = models.CharField('Parent Password', max_length=50)
    Parent_Email = models.EmailField('Parent Email', max_length=50)

#class Student(models.Model):
#    Student_ID = models.CharField('Student ID', max_length=5)
#    Student_Name = models.CharField('Student Name', max_length=50)
#    Student_Gender = models.CharField('Student Gender', max_length=10)
#    Student_Race = models.CharField('Student Race', max_length=10)
#    Student_Grade = models.IntegerField('Student Grade')

    def _str_(self):
        return self.name