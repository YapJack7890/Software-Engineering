from django.shortcuts import render

# Create your views here.
def home(request):

        return render(request, 'home')


def register(request):
    
    return render(request, 'register')

def login(request):
    return render(request, 'login.html')