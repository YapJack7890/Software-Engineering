from django.urls import path
from mycanteen.views import item_list

urlpatterns = [
    path('items/', item_list, name='item_list'),
]
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('mycanteen/', include('mycanteen.urls')),
]
